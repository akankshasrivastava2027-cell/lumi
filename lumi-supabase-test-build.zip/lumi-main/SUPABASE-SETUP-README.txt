LUMI SUPABASE INTEGRATION — TEST BUILD (NOT PAYMENT READY)

This build connects the site to Supabase Email OTP/magic-link sign-in.
- Server reads lumi_accounts for remaining free uses and premium_until.
- Each completed activity calls the server-side complete_lumi_activity RPC.
- Premium status is read from Supabase, never browser-local state.
- The five-use allowance cannot be reset by Start fresh or localStorage edits.
- Payment collection is intentionally DISABLED until Razorpay webhook verification,
  secure customer/payment mapping, and idempotent fulfillment are implemented.

IMPORTANT: This is not production-ready for payments. Test login and counting
before deploying. Existing users' local usage counts are not migrated into
Supabase; server accounts start at zero unless separately reconciled.

Email OTP requires Supabase Auth URL Configuration Site URL and Redirect URL
https://meetlumi.in/ and an operational email provider. Supabase's built-in
mailer may have sending restrictions and rate limits.

Testing:
1. Open test version on HTTPS origin allowed by Supabase redirect settings.
2. Sign in via email link.
3. Complete one activity and check lumi_accounts.free_uses = 1.
4. Start fresh, verify free_uses is still 1.
5. Verify five completions reach 5 and the sixth is blocked.
6. Verify sign-out and sign-in on another browser preserves the count.

LIMITATIONS:
- A malicious client can invoke the completion RPC directly to CONSUME their
  own quota; it cannot grant extra free uses or premium. Strong activity
  completion attestation would require a server-issued activity session.
- Garden and journal remain device-local. Do not claim they sync across devices.
- Razorpay checkout is not yet enabled.
